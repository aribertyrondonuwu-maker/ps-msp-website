async function loadMedia() {
  try {
    const res = await fetch('js/data/media.json');
    const data = await res.json();

    // ── YouTube: embed responsif ──
    function ytId(url) {
      const m = url.match(/[?&]v=([^&]+)/) || url.match(/youtu\.be\/([^?&]+)/);
      return m ? m[1] : null;
    }
    const ytGrid = document.getElementById('ytGrid');
    if (ytGrid && Array.isArray(data.youtube)) {
      ytGrid.innerHTML = data.youtube.map(url => {
        const id = ytId(url);
        if (!id) return '';
        return `
          <div class="video-embed">
            <iframe src="https://www.youtube.com/embed/${id}" title="Video YouTube PS MSP"
              loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowfullscreen></iframe>
          </div>`;
      }).join('');
    }

    // ── TikTok: kartu link (embed penuh perlu script tiktok, ini lebih ringan & stabil) ──
    function ttMeta(url) {
      const acc = (url.match(/@([^/]+)/) || [])[1] || 'akun';
      return { akun: '@' + acc };
    }
    const ttGrid = document.getElementById('ttGrid');
    if (ttGrid && Array.isArray(data.tiktok)) {
      ttGrid.innerHTML = data.tiktok.map(url => {
        const { akun } = ttMeta(url);
        return `
          <a href="${url}" target="_blank" rel="noopener" class="card tiktok-card">
            <div class="tiktok-icon" aria-hidden="true">
              <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>
            </div>
            <div class="tiktok-body">
              <span class="tiktok-akun">${akun}</span>
              <span class="tiktok-cta">Tonton di TikTok →</span>
            </div>
          </a>`;
      }).join('');
    }

    // ── Akun resmi (Facebook + YouTube channel) ──
    const akunEl = document.getElementById('mediaAkunGrid');
    if (akunEl && data.akun) {
      const cards = [];
      if (data.akun.facebook) {
        cards.push(`<a href="${data.akun.facebook}" target="_blank" rel="noopener" class="card akun-card"><h3>Facebook</h3><p>Ikuti halaman resmi PS MSP FPIK UNSRAT</p><span class="card-link">Buka Facebook →</span></a>`);
      }
      if (data.akun.youtube_channel) {
        cards.push(`<a href="${data.akun.youtube_channel}" target="_blank" rel="noopener" class="card akun-card"><h3>YouTube</h3><p>Kanal video Prodi MSP FPIK UNSRAT</p><span class="card-link">Buka Kanal YouTube →</span></a>`);
      }
      akunEl.innerHTML = cards.join('');
    }

    // Update jumlah di sub-judul
    const ytCount = document.getElementById('ytCount');
    if (ytCount) ytCount.textContent = (data.youtube || []).length;
    const ttCount = document.getElementById('ttCount');
    if (ttCount) ttCount.textContent = (data.tiktok || []).length;
  } catch (e) {
    console.error('Gagal memuat data media:', e);
  }
}
loadMedia();
